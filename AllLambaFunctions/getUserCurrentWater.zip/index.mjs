import AWS from "aws-sdk";

const dynamoDB = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  if (event.httpMethod === "OPTIONS") {
    console.log("Handling OPTIONS request");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "CORS preflight check passed" }),
    };
  }

  // Check if the request body exists
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Request body is required" }),
    };
  }

  let userId;

  try {
    // Parse the request body
    const requestBody = JSON.parse(event.body);
    userId = requestBody.userId;

    if (!userId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "User ID is required" }),
      };
    }
  } catch (error) {
    console.error("Error parsing request body:", error);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Invalid JSON in request body" }),
    };
  }

  console.log(`Looking for user with ID: ${userId}`);

  const params = {
    TableName: "Users", // DynamoDB table name
    Key: { userId }, // Primary key
  };

  try {
    // Fetch user details from DynamoDB
    const result = await dynamoDB.get(params).promise();

    if (!result.Item) {
      console.error("User not found in the database");
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "User not found" }),
      };
    }

    console.log("User found:", result.Item);

    // Extract currentWater or set to default value
    const currentWater = result.Item.currentWater || 0;

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "User details fetched successfully",
        currentWater: currentWater,
      }),
    };
  } catch (error) {
    console.error("Error fetching user from DynamoDB:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Error fetching user details",
        error: error.message,
      }),
    };
  }
};
