const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const AWS = require("aws-sdk");

const region = "us-east-1"; // Replace with your region
const userPoolId = "us-east-1_K3uUYBPxr"; // Replace with your User Pool ID
const audience = "6k3bof5l7k40ppo8lp3ugafhbg"; // Replace with your App Client ID
const issuer = `https://cognito-idp.${region}.amazonaws.com/${userPoolId}`;

const client = jwksClient({
  jwksUri: `${issuer}/.well-known/jwks.json`,
});

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const usersTableName = "Users"; // Replace with your DynamoDB table name

function getSigningKey(kid) {
  return new Promise((resolve, reject) => {
    client.getSigningKey(kid, (err, key) => {
      if (err) {
        reject(err);
      } else {
        resolve(key.getPublicKey());
      }
    });
  });
}

exports.handler = async (event) => {
  try {
    const authHeader = event.headers?.Authorization;
    if (!authHeader) {
      return {
        statusCode: 401,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
        },
        body: JSON.stringify({
          message: "Unauthorized: Missing Authorization header",
        }),
      };
    }

    const token = authHeader.replace("Bearer ", "");

    const { kid } = jwt.decode(token, { complete: true }).header;
    const publicKey = await getSigningKey(kid);

    const decodedToken = jwt.verify(token, publicKey, {
      algorithms: ["RS256"],
      audience: audience,
      issuer: issuer,
    });

    const groups = decodedToken["cognito:groups"] || [];
    const isAdmin = groups.includes("Admins");

    if (!isAdmin) {
      return {
        statusCode: 403,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
        },
        body: JSON.stringify({
          message: "Forbidden: User is not an Admin",
        }),
      };
    }

    // Fetch all data from the Users table
    const usersData = await dynamoDB
      .scan({ TableName: usersTableName })
      .promise();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({
        message: "User is an Admin",
        users: usersData.Items,
      }),
    };
  } catch (err) {
    return {
      statusCode: 401,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Unauthorized", error: err.message }),
    };
  }
};
