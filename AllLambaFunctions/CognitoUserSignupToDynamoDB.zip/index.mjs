import AWS from "aws-sdk";

const dynamoDB = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  console.log("Event received:", JSON.stringify(event, null, 2));

  const userAttributes = event.request.userAttributes;

  if (!userAttributes.sub || !userAttributes.email) {
    console.error("Missing required user attributes");
    return {
      statusCode: 400,
      body: "Invalid user data",
    };
  }

  const params = {
    TableName: "Users",
    Item: {
      userId: userAttributes.sub,
      email: userAttributes.email,
      givenName: userAttributes.given_name || "No First Name",
      familyName: userAttributes.family_name || "No Last Name",
      birthdate: userAttributes.birthdate || "No Birthdate",
      gender: userAttributes.gender || "No Gender",
      signupDate: new Date().toISOString(),
      waterGoal: 0,
      recommendedWater: 0,
      currentWater: 0,
      streak: 0,
    },
  };

  try {
    await dynamoDB.put(params).promise();
    console.log(`User ${userAttributes.email} added to DynamoDB`);
  } catch (error) {
    console.error("Error adding user to DynamoDB:", error);
    throw new Error("Could not add user to DynamoDB");
  }

  return event;
};
