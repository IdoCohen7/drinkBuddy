import AWS from "aws-sdk";

const dynamoDB = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  // טיפול בבקשת OPTIONS (Preflight)
  if (event.httpMethod === "OPTIONS") {
    console.log("Handling OPTIONS request");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "CORS preflight check passed" }),
    };
  }

  // בדיקת קלט
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Request body is required" }),
    };
  }

  try {
    const requestBody = JSON.parse(event.body);
    const userId = requestBody.userId;

    if (!userId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "User ID is required" }),
      };
    }

    // Fetch מה-DynamoDB
    const result = await dynamoDB
      .get({ TableName: "Users", Key: { userId } })
      .promise();

    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "User not found" }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ userDetails: result.Item }),
    };
  } catch (error) {
    console.error("Error:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Internal server error",
        error: error.message,
      }),
    };
  }
};
